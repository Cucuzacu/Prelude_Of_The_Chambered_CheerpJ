package com.mojang.escape.menu;

import com.mojang.escape.*;
import com.mojang.escape.gui.Bitmap;

public class Menu {
	public void render(Bitmap target) {
	}

	public void tick(Game game, boolean up, boolean down, boolean left, boolean right, boolean use) {
	}
}