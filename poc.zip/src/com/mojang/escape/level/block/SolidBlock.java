package com.mojang.escape.level.block;

public class SolidBlock extends Block {
	public SolidBlock() {
		solidRender = true;
		blocksMotion = true;
	}
}
